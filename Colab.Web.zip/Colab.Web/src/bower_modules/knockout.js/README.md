knockout
========

compiled knockout libs for bowerjs
